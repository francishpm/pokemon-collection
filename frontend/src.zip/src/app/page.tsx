import { Header } from "@/components/layout/Header";
import { StatCard } from "@/components/dashboard/StatCard";
import { GoalCard } from "@/components/dashboard/GoalCard";
import { Sidebar } from "@/components/layout/Sidebar";
import { Topbar } from "@/components/layout/Topbar";
import { getGreeting } from "@/lib/greeting";

export default function Home() {
  return (
  <main className="flex min-h-screen bg-slate-50">

    <Sidebar />

    <div className="flex-1">

      <Topbar />

      <div className="mx-auto max-w-7xl p-8">

        <h2 className="text-3xl font-bold text-gray-900">
        {getGreeting()}, Francis 👋
        </h2>

        <p className="mt-2 text-gray-600">
          Bem-vindo ao seu gerenciador de coleção.
        </p>

        <div className="mt-10 grid gap-6 md:grid-cols-3">

          <StatCard
            icon="🎴"
            title="Cartas"
            value="0"
          />

          <StatCard
            icon="⭐"
            title="Wishlist"
            value="0"
          />

          <StatCard
            icon="💰"
            title="Valor da coleção"
            value="R$ 0,00"
          />

        </div>

        <div className="mt-8 grid gap-6 md:grid-cols-3">
          <GoalCard />
        </div>

      </div>

    </div>

  </main>
);
}