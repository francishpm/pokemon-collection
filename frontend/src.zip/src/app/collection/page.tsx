"use client";

import { Search, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useEffect, useMemo, useState } from "react";
import { PokemonCard } from "@/types/pokemon-card";
import { searchCards } from "@/services/pokemonApi";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function CollectionPage() {
  const [open, setOpen] = useState(false);

  const [search, setSearch] = useState("");

  const [apiCards, setApiCards] = useState<PokemonCard[]>([]);

  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const loadCards = async () => {
      const term = search.trim();

      const isNumber = /^\d+$/.test(term);
      const isFullNumber = /^\d+\/\d+$/.test(term);

      if (
        term.length < 3 &&
        !isNumber &&
        !isFullNumber
      ) {
        setApiCards([]);
        return;
      }

      try {
        setLoading(true);

        const result = await searchCards(term);

        setApiCards(result);
      } catch (error) {
        console.error(error);
      } finally {
        setLoading(false);
      }
    };

    const timeout = setTimeout(loadCards, 350);

    return () => clearTimeout(timeout);
  }, [search]);

  const cards = useMemo(() => {
    const term = search.trim().toLowerCase();

    if (!term) return [];

    return apiCards.filter((card) => {
      const fullNumber =
        `${card.number}/${card.set.printedTotal}`.toLowerCase();

      return (
        card.name.toLowerCase().includes(term) ||
        card.number.toLowerCase().includes(term) ||
        fullNumber.includes(term) ||
        card.set.name.toLowerCase().includes(term)
      );
    });
  }, [apiCards, search]);

  return (
    <div className="space-y-8">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">
          Minha Coleção
        </h1>

        <p className="mt-2 text-muted-foreground">
          Gerencie todas as cartas da sua coleção Pokémon.
        </p>
      </div>

      <div className="flex flex-col gap-4 md:flex-row">
        <div className="relative flex-1">
          <Search
            className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground"
            size={18}
          />

          <Input
            placeholder="Pesquisar cartas..."
            className="pl-10"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <Button
          className="gap-2"
          onClick={() => setOpen(true)}
        >
          <Plus size={18} />
          Adicionar Carta
        </Button>
      </div>

      <div className="rounded-xl border bg-card p-12 text-center">
        <h2 className="text-xl font-semibold">
          Nenhuma carta cadastrada
        </h2>

        <p className="mt-2 text-muted-foreground">
          Sua coleção aparecerá aqui assim que você adicionar sua primeira carta.
        </p>
      </div>

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>Adicionar Carta</DialogTitle>

            <DialogDescription>
              Pesquise uma carta Pokémon para adicionar à sua coleção.
            </DialogDescription>
          </DialogHeader>

          <div className="space-y-6">
            <Input
              placeholder="Pesquisar carta..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />

            <div className="max-h-[450px] overflow-y-auto rounded-lg border">
              {loading ? (
                <div className="p-10 text-center text-muted-foreground">
                  Carregando...
                </div>
              ) : cards.length === 0 ? (
                <div className="p-10 text-center text-muted-foreground">
                  Nenhuma carta encontrada.
                </div>
              ) : (
                cards.map((card) => (
                  <div
                    key={card.id}
                    className="flex cursor-pointer items-center gap-4 border-b p-4 transition-colors hover:bg-muted last:border-b-0"
                  >
                    <img
                      src={card.images.small}
                      alt={card.name}
                      className="h-20 rounded"
                    />

                    <div className="flex-1">
                      <p className="font-medium">
                        {card.name}
                      </p>

                      <p className="text-sm text-muted-foreground">
                        {card.set.name}
                      </p>

                      <p className="text-xs text-muted-foreground">
                        #{card.number}/{card.set.printedTotal}
                      </p>
                    </div>

                    <Button size="sm">
                      Adicionar
                    </Button>
                  </div>
                ))
              )}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}