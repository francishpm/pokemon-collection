export interface PokemonCard {
  id: string;
  name: string;
  number: string;

  images: {
    small: string;
    large: string;
  };

  set: {
    id: string;
    name: string;
    series: string;
    printedTotal: number;
  };
}