export type CardCondition =
  | "M"
  | "NM"
  | "SP"
  | "MP"
  | "HP"
  | "D";

export type CardLanguage =
  | "PT"
  | "EN"
  | "JP";

export interface CollectionCard {
  id: string;

  pokemonCardId: string;

  name: string;

  image: string;

  number: string;

  setId: string;

  setName: string;

  quantity: number;

  language: CardLanguage;

  condition: CardCondition;

  purchasePrice: number;

  purchaseDate?: string;

  foil: boolean;

  reverse: boolean;

  notes?: string;
}